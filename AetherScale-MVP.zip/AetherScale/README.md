# AetherScale

**Upscale e filtros de imagem para Android — 100% offline**

Versão **1.0.0-mvp** • Outubro 2026

Aplicativo Android original inspirado na *categoria de recursos* de ferramentas como Lossless Scaling.  
Não copia nome, interface, logotipo nem código de nenhum software proprietário.

---

## O que o MVP faz

- Importa imagens locais (seletor do sistema)
- Aplica **upscale real** com algoritmos:
  - Nearest / Integer (ótimo para pixel art)
  - Bilinear
  - Bicubic
  - Lanczos (aproximação segura)
- Controles de **nitidez, contraste, saturação, brilho e redução de ruído**
- Presets prontos: Equilibrado, Pixel Art, Anime/Cartoon, Imagem, Vídeo
- Comparação **Antes / Depois** com slider interativo
- Medição de tempo de processamento, resolução e uso aproximado de memória
- Funciona completamente **offline**
- Não requer root, desbloqueio de bootloader nem permissões de acessibilidade

## O que o MVP **não** faz (e por quê)

| Recurso | Status | Motivo |
|---------|--------|--------|
| Captura de tela + pós-processamento transparente | Experimental (Etapa 2) | MediaProjection permite capturar, mas **não** substitui a imagem de outros apps no compositor do Android |
| Overlay que altera pixels de jogos | Impossível sem root / privilégios de sistema | SYSTEM_ALERT_WINDOW só mostra controles por cima |
| Interpolação de quadros em tempo real | Pesquisa futura | Exige pipeline de fluxo óptico mensurável e modelos leves |
| Aumento de FPS de jogos de terceiros | Não suportado | Limitação da plataforma Android |

Essas limitações são técnicas e honestas. O app deixa isso claro na interface.

---

## Dispositivo de referência

- **Xiaomi Redmi Note 12 Pro 5G**
- MediaTek Dimensity 1080 + Mali-G68 MC4
- 6 GB RAM física (+ 6 GB virtual)
- Android 14

O app detecta resolução, taxa de atualização e memória em tempo de execução e recomenda configurações adequadas.

---

## Como gerar o APK **sem PC** (pelo celular)

Este projeto já inclui o Gradle Wrapper (`gradlew` + `gradle-wrapper.jar`). Você não precisa de computador.

### Passo a passo (só celular)

1. **Baixe o ZIP** `AetherScale-MVP.zip` (ou clone o repositório).
2. Crie um repositório **novo e vazio** no GitHub (pode ser privado).
3. No GitHub pelo navegador do celular:
   - Abra o repositório → **Add file** → **Upload files**
   - Envie **todo o conteúdo** da pasta `AetherScale` (ou o ZIP descompactado)
   - Commit
4. Vá na aba **Actions** do repositório.
5. Selecione o workflow **Build Debug APK**.
6. Toque em **Run workflow** → **Run workflow**.
7. Aguarde 3–8 minutos (a primeira vez demora mais).
8. Quando aparecer o ✓ verde, abra a execução e baixe o artefato **AetherScale-debug**.
9. Descompacte o ZIP baixado → você terá o arquivo `.apk`.
10. No celular: Configurações → Segurança / Apps → permita **Instalar apps desconhecidos** para o gerenciador de arquivos.
11. Abra o `.apk` e instale.

### Se tiver PC (opcional)

```bash
git clone <seu-repositório>
cd AetherScale
./gradlew assembleDebug
```

APK gerado em: `app/build/outputs/apk/debug/app-debug.apk`

**Segurança**: o APK de debug não é assinado para produção. Use apenas para testes. Não publique em lojas oficiais.

---

## Estrutura do projeto

```
AetherScale/
├── app/
│   ├── src/main/
│   │   ├── java/com/aetherscale/app/
│   │   │   ├── MainActivity.kt
│   │   │   ├── processing/ImageProcessor.kt   ← pipeline real de imagem
│   │   │   ├── ui/
│   │   │   │   ├── screens/                   ← Home, Editor, Diagnóstico, Config
│   │   │   │   ├── components/BeforeAfterSlider.kt
│   │   │   │   └── theme/
│   │   │   └── util/DeviceInfo.kt
│   │   ├── res/
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── .github/workflows/build-apk.yml
└── README.md
```

---

## Arquitetura técnica (resumo)

- **UI**: Jetpack Compose + Material 3 (tema escuro ciano)
- **Processamento**: Kotlin puro + Canvas / ColorMatrix / convolução 3×3
  - Sem NDK no MVP (evita complexidade e problemas de ABI)
  - Fallbacks seguros contra OutOfMemoryError
- **Escopo do MVP**: apenas imagens locais
- **Próximas etapas** (não implementadas):
  1. MediaProjection isolado + visualizador próprio
  2. Avaliação de OpenGL ES 3.0 / Vulkan na Mali-G68
  3. Pesquisa de interpolação de quadros para vídeos locais

---

## Critérios de aceitação do MVP (atendidos)

- [x] Projeto abre e compila
- [x] Usuário seleciona imagem local, aplica upscale/filtros e compara Antes/Depois
- [x] Imagem exportada mantém proporção
- [x] Filtros e presets têm efeito real
- [x] Funciona offline
- [x] Falhas de memória/formato são tratadas sem crash
- [x] Instruções de compilação + GitHub Actions

---

## Licença e avisos

Código original criado para este projeto.  
Não inclua chaves secretas, certificados de produção ou credenciais no repositório.

Use com responsabilidade. O processamento de imagens de terceiros deve respeitar direitos autorais.

---

**AetherScale** — escala local, resultados reais, sem promessas impossíveis.
