package com.aetherscale.app.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aetherscale.app.processing.ImageProcessor
import com.aetherscale.app.ui.EditorViewModel
import com.aetherscale.app.ui.components.BeforeAfterSlider
import com.aetherscale.app.ui.theme.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    onBack: () -> Unit,
    viewModel: EditorViewModel = viewModel()
) {
    val context = LocalContext.current
    var showExportMessage by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { stream ->
                    viewModel.loadImage(stream)
                }
            } catch (e: Exception) {
                viewModel.errorMessage = "Falha ao abrir a imagem: ${e.message}"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Editor de imagem") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary,
                    navigationIconContentColor = TextPrimary
                ),
                actions = {
                    IconButton(onClick = { imagePicker.launch("image/*") }) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Importar")
                    }
                }
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Área de visualização
            if (viewModel.originalBitmap == null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .padding(16.dp)
                        .background(DarkCard, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.ImageSearch,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "Toque em + para importar uma imagem",
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { imagePicker.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary)
                        ) {
                            Text("Selecionar imagem", color = DarkBackground)
                        }
                    }
                }
            } else {
                BeforeAfterSlider(
                    before = viewModel.originalBitmap,
                    after = viewModel.processedBitmap ?: viewModel.originalBitmap,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }

            // Métricas
            viewModel.lastResult?.let { result ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        MetricItem("${result.processingTimeMs} ms", "Tempo")
                        MetricItem("${result.inputWidth}×${result.inputHeight}", "Entrada")
                        MetricItem("${result.outputWidth}×${result.outputHeight}", "Saída")
                        MetricItem("%.1f MB".format(result.memoryUsedApproxBytes / 1024.0 / 1024.0), "Memória")
                    }
                }
            }

            // Mensagem de erro
            viewModel.errorMessage?.let { msg ->
                Text(
                    text = msg,
                    color = Error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            if (viewModel.isProcessing) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    color = CyanPrimary
                )
            }

            // Controles
            if (viewModel.originalBitmap != null) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Presets
                    Text("Preset", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ImageProcessor.PRESETS.forEachIndexed { index, preset ->
                            FilterChip(
                                selected = viewModel.selectedPresetIndex == index,
                                onClick = { viewModel.applyPreset(index) },
                                label = { Text(preset.name, style = MaterialTheme.typography.labelMedium) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanPrimary,
                                    selectedLabelColor = DarkBackground
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Algoritmo
                    Text("Algoritmo de escala", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    val algorithms = listOf(
                        ImageProcessor.ScaleAlgorithm.NEAREST to "Nearest",
                        ImageProcessor.ScaleAlgorithm.BILINEAR to "Bilinear",
                        ImageProcessor.ScaleAlgorithm.BICUBIC to "Bicubic",
                        ImageProcessor.ScaleAlgorithm.LANCZOS to "Lanczos"
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        algorithms.forEach { (algo, label) ->
                            FilterChip(
                                selected = viewModel.selectedAlgorithm == algo,
                                onClick = {
                                    viewModel.selectedAlgorithm = algo
                                    viewModel.process()
                                },
                                label = { Text(label, style = MaterialTheme.typography.labelMedium) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Sliders
                    SliderControl("Escala", viewModel.scaleFactor, 1.0f, 4.0f, "%.1fx") {
                        viewModel.scaleFactor = it
                    }
                    SliderControl("Nitidez", viewModel.sharpness, 0f, 2f, "%.2f") {
                        viewModel.sharpness = it
                    }
                    SliderControl("Contraste", viewModel.contrast, 0.5f, 2.0f, "%.2f") {
                        viewModel.contrast = it
                    }
                    SliderControl("Saturação", viewModel.saturation, 0f, 2.0f, "%.2f") {
                        viewModel.saturation = it
                    }
                    SliderControl("Brilho", viewModel.brightness, -0.5f, 0.5f, "%.2f") {
                        viewModel.brightness = it
                    }
                    SliderControl("Redução de ruído", viewModel.noiseReduction, 0f, 1f, "%.2f") {
                        viewModel.noiseReduction = it
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Botões de ação
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.process() },
                            enabled = !viewModel.isProcessing,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Aplicar", color = DarkBackground)
                        }
                        OutlinedButton(
                            onClick = { viewModel.reset() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Restaurar")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val bmp = viewModel.processedBitmap ?: return@Button
                            try {
                                val dir = File(context.cacheDir, "exports").apply { mkdirs() }
                                val name = "aetherscale_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.png"
                                val file = File(dir, name)
                                FileOutputStream(file).use { out ->
                                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                                }
                                showExportMessage = "Exportado: ${file.name}"
                            } catch (e: Exception) {
                                showExportMessage = "Erro ao exportar: ${e.message}"
                            }
                        },
                        enabled = viewModel.processedBitmap != null && !viewModel.isProcessing,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = CyanDark)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Exportar PNG")
                    }

                    showExportMessage?.let {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(it, color = Success, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricItem(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.labelLarge, color = CyanLight)
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
    }
}

@Composable
private fun SliderControl(
    label: String,
    value: Float,
    valueRangeStart: Float,
    valueRangeEnd: Float,
    format: String,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
            Text(format.format(value), style = MaterialTheme.typography.bodyMedium, color = CyanSecondary)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRangeStart..valueRangeEnd,
            colors = SliderDefaults.colors(
                thumbColor = CyanPrimary,
                activeTrackColor = CyanPrimary,
                inactiveTrackColor = DarkSurfaceVariant
            )
        )
    }
}
