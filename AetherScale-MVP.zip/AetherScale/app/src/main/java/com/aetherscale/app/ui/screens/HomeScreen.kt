package com.aetherscale.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aetherscale.app.ui.theme.*
import com.aetherscale.app.util.DeviceDiagnostics
import com.aetherscale.app.util.DeviceInfo

@Composable
fun HomeScreen(
    diagnostics: DeviceDiagnostics?,
    onOpenEditor: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        // Header
        Text(
            text = "AetherScale",
            style = MaterialTheme.typography.displayLarge,
            color = CyanPrimary,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Upscale e filtros locais • 100% offline",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Status do dispositivo
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Dispositivo",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (diagnostics != null) {
                    Text(
                        text = "${diagnostics.manufacturer} ${diagnostics.model}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = CyanLight
                    )
                    Text(
                        text = "Android ${diagnostics.androidVersion} (API ${diagnostics.apiLevel})",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    Text(
                        text = "RAM: ${DeviceInfo.formatRam(diagnostics.availableRamMb)} disponível / ${DeviceInfo.formatRam(diagnostics.totalRamMb)} total",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                    Text(
                        text = "${diagnostics.screenWidthPx}×${diagnostics.screenHeightPx} @ ${diagnostics.refreshRateHz} Hz",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                } else {
                    Text("Coletando informações…", color = TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Botão principal
        Button(
            onClick = onOpenEditor,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Default.AutoFixHigh, contentDescription = null)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "Abrir ferramenta de imagem",
                style = MaterialTheme.typography.titleMedium,
                color = DarkBackground
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Recursos
        Text(
            text = "Recursos",
            style = MaterialTheme.typography.titleLarge,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(12.dp))

        FeatureCard(
            icon = Icons.Default.Image,
            title = "Upscale + Filtros",
            status = "Disponível",
            statusColor = Success,
            description = "Nearest, Bilinear, Bicubic, Lanczos aproximado. Nitidez, contraste, saturação, brilho e redução de ruído."
        )
        FeatureCard(
            icon = Icons.Default.Compare,
            title = "Comparação Antes / Depois",
            status = "Disponível",
            statusColor = Success,
            description = "Slider interativo para verificar o resultado em tempo real."
        )
        FeatureCard(
            icon = Icons.Default.Tune,
            title = "Presets prontos",
            status = "Disponível",
            statusColor = Success,
            description = "Pixel Art, Anime/Cartoon, Imagem, Vídeo e Equilibrado."
        )
        FeatureCard(
            icon = Icons.Default.Screenshot,
            title = "Captura de tela (MediaProjection)",
            status = "Experimental (Etapa 2)",
            statusColor = Experimental,
            description = "Não implementado no MVP. Requer consentimento do usuário e não altera a imagem de outros apps de forma transparente."
        )
        FeatureCard(
            icon = Icons.Default.Movie,
            title = "Interpolação de quadros",
            status = "Pesquisa futura",
            statusColor = Unsupported,
            description = "Não implementado. Requer pipeline real de fluxo óptico e medição de latência/consumo."
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Aviso importante
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    Icons.Default.Info,
                    contentDescription = null,
                    tint = CyanSecondary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Este aplicativo processa apenas imagens e vídeos fornecidos por você. Não captura nem altera a tela de outros jogos em tempo real. Não requer root.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onOpenDiagnostics,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Analytics, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Diagnóstico")
            }
            OutlinedButton(
                onClick = onOpenSettings,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Configurações")
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
private fun FeatureCard(
    icon: ImageVector,
    title: String,
    status: String,
    statusColor: androidx.compose.ui.graphics.Color,
    description: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = CyanPrimary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Text(
                    text = status,
                    style = MaterialTheme.typography.labelMedium,
                    color = statusColor
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}
