package com.aetherscale.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.aetherscale.app.ui.screens.DiagnosticsScreen
import com.aetherscale.app.ui.screens.EditorScreen
import com.aetherscale.app.ui.screens.HomeScreen
import com.aetherscale.app.ui.screens.SettingsScreen
import com.aetherscale.app.ui.theme.AetherScaleTheme
import com.aetherscale.app.ui.theme.DarkBackground
import com.aetherscale.app.util.DeviceDiagnostics
import com.aetherscale.app.util.DeviceInfo

sealed class Screen {
    data object Home : Screen()
    data object Editor : Screen()
    data object Diagnostics : Screen()
    data object Settings : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AetherScaleTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBackground
                ) {
                    AetherScaleApp()
                }
            }
        }
    }
}

@Composable
fun AetherScaleApp() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }
    val context = LocalContext.current
    var diagnostics by remember { mutableStateOf<DeviceDiagnostics?>(null) }

    LaunchedEffect(Unit) {
        diagnostics = DeviceInfo.collect(context)
    }

    when (currentScreen) {
        Screen.Home -> HomeScreen(
            diagnostics = diagnostics,
            onOpenEditor = { currentScreen = Screen.Editor },
            onOpenDiagnostics = { currentScreen = Screen.Diagnostics },
            onOpenSettings = { currentScreen = Screen.Settings }
        )
        Screen.Editor -> EditorScreen(
            onBack = { currentScreen = Screen.Home }
        )
        Screen.Diagnostics -> DiagnosticsScreen(
            diagnostics = diagnostics,
            onBack = { currentScreen = Screen.Home }
        )
        Screen.Settings -> SettingsScreen(
            onBack = { currentScreen = Screen.Home }
        )
    }
}
