package com.aetherscale.app.processing

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.*

/**
 * Pipeline de processamento de imagem do AetherScale.
 * Implementação real (não decorativa) com fallbacks seguros.
 * Prioriza estabilidade em dispositivos com 6 GB de RAM física (ex.: Redmi Note 12 Pro 5G).
 */
object ImageProcessor {

    enum class ScaleAlgorithm {
        NEAREST,    // Integer / nearest-neighbor (ótimo para pixel art)
        BILINEAR,
        BICUBIC,
        LANCZOS     // Aproximação de Lanczos-3
    }

    data class ProcessParams(
        val scaleFactor: Float = 2.0f,
        val algorithm: ScaleAlgorithm = ScaleAlgorithm.BICUBIC,
        val sharpness: Float = 0.0f,      // -1.0 .. 2.0
        val contrast: Float = 1.0f,       // 0.5 .. 2.0
        val saturation: Float = 1.0f,     // 0.0 .. 2.0
        val brightness: Float = 0.0f,     // -0.5 .. 0.5
        val noiseReduction: Float = 0.0f, // 0.0 .. 1.0
        val maxOutputDimension: Int = 4096 // proteção contra OOM
    )

    data class ProcessResult(
        val bitmap: Bitmap,
        val processingTimeMs: Long,
        val inputWidth: Int,
        val inputHeight: Int,
        val outputWidth: Int,
        val outputHeight: Int,
        val memoryUsedApproxBytes: Long
    )

    data class Preset(
        val name: String,
        val params: ProcessParams
    )

    val PRESETS = listOf(
        Preset(
            "Equilibrado",
            ProcessParams(
                scaleFactor = 2.0f,
                algorithm = ScaleAlgorithm.BICUBIC,
                sharpness = 0.4f,
                contrast = 1.05f,
                saturation = 1.05f,
                brightness = 0.0f,
                noiseReduction = 0.15f
            )
        ),
        Preset(
            "Pixel Art",
            ProcessParams(
                scaleFactor = 3.0f,
                algorithm = ScaleAlgorithm.NEAREST,
                sharpness = 0.0f,
                contrast = 1.1f,
                saturation = 1.0f,
                brightness = 0.0f,
                noiseReduction = 0.0f
            )
        ),
        Preset(
            "Anime / Cartoon",
            ProcessParams(
                scaleFactor = 2.0f,
                algorithm = ScaleAlgorithm.BICUBIC,
                sharpness = 0.7f,
                contrast = 1.15f,
                saturation = 1.2f,
                brightness = 0.02f,
                noiseReduction = 0.25f
            )
        ),
        Preset(
            "Imagem",
            ProcessParams(
                scaleFactor = 2.0f,
                algorithm = ScaleAlgorithm.LANCZOS,
                sharpness = 0.35f,
                contrast = 1.08f,
                saturation = 1.05f,
                brightness = 0.0f,
                noiseReduction = 0.2f
            )
        ),
        Preset(
            "Vídeo",
            ProcessParams(
                scaleFactor = 1.5f,
                algorithm = ScaleAlgorithm.BILINEAR,
                sharpness = 0.25f,
                contrast = 1.0f,
                saturation = 1.0f,
                brightness = 0.0f,
                noiseReduction = 0.3f
            )
        )
    )

    /**
     * Processa a imagem de forma assíncrona e segura.
     * Libera bitmaps intermediários e respeita limite de dimensão.
     */
    suspend fun process(
        source: Bitmap,
        params: ProcessParams
    ): ProcessResult = withContext(Dispatchers.Default) {
        val start = SystemClock.elapsedRealtime()

        // Proteção contra imagens muito grandes
        val safeSource = if (source.width > 4096 || source.height > 4096) {
            val ratio = minOf(4096f / source.width, 4096f / source.height)
            val w = (source.width * ratio).toInt().coerceAtLeast(1)
            val h = (source.height * ratio).toInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(source, w, h, true)
        } else {
            source
        }

        val targetW = (safeSource.width * params.scaleFactor)
            .toInt()
            .coerceIn(1, params.maxOutputDimension)
        val targetH = (safeSource.height * params.scaleFactor)
            .toInt()
            .coerceIn(1, params.maxOutputDimension)

        // 1. Upscale
        val scaled = when (params.algorithm) {
            ScaleAlgorithm.NEAREST -> scaleNearest(safeSource, targetW, targetH)
            ScaleAlgorithm.BILINEAR -> scaleBilinear(safeSource, targetW, targetH)
            ScaleAlgorithm.BICUBIC -> scaleBicubic(safeSource, targetW, targetH)
            ScaleAlgorithm.LANCZOS -> scaleLanczosApprox(safeSource, targetW, targetH)
        }

        if (safeSource !== source && !safeSource.isRecycled) {
            safeSource.recycle()
        }

        // 2. Ajustes de cor (ColorMatrix é rápido e eficiente)
        var current = applyColorAdjustments(
            scaled,
            contrast = params.contrast,
            saturation = params.saturation,
            brightness = params.brightness
        )
        if (current !== scaled && !scaled.isRecycled) {
            scaled.recycle()
        }

        // 3. Nitidez (unsharp mask leve)
        if (params.sharpness > 0.01f) {
            val sharpened = applySharpen(current, params.sharpness)
            if (sharpened !== current && !current.isRecycled) {
                current.recycle()
            }
            current = sharpened
        }

        // 4. Redução de ruído (média 3x3 controlada)
        if (params.noiseReduction > 0.01f) {
            val denoised = applyNoiseReduction(current, params.noiseReduction)
            if (denoised !== current && !current.isRecycled) {
                current.recycle()
            }
            current = denoised
        }

        val elapsed = SystemClock.elapsedRealtime() - start
        val approxMem = current.byteCount.toLong()

        ProcessResult(
            bitmap = current,
            processingTimeMs = elapsed,
            inputWidth = source.width,
            inputHeight = source.height,
            outputWidth = current.width,
            outputHeight = current.height,
            memoryUsedApproxBytes = approxMem
        )
    }

    // ========== Algoritmos de escala ==========

    private fun scaleNearest(src: Bitmap, dstW: Int, dstH: Int): Bitmap {
        val dst = Bitmap.createBitmap(dstW, dstH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dst)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            isFilterBitmap = false // nearest
            isAntiAlias = false
        }
        canvas.drawBitmap(src, null, Rect(0, 0, dstW, dstH), paint)
        return dst
    }

    private fun scaleBilinear(src: Bitmap, dstW: Int, dstH: Int): Bitmap {
        return Bitmap.createScaledBitmap(src, dstW, dstH, true)
    }

    private fun scaleBicubic(src: Bitmap, dstW: Int, dstH: Int): Bitmap {
        // Implementação simples de bicúbico via amostragem (boa qualidade x custo)
        val dst = Bitmap.createBitmap(dstW, dstH, Bitmap.Config.ARGB_8888)
        val srcW = src.width
        val srcH = src.height
        val xRatio = (srcW - 1).toFloat() / (dstW - 1).coerceAtLeast(1)
        val yRatio = (srcH - 1).toFloat() / (dstH - 1).coerceAtLeast(1)

        val pixels = IntArray(dstW * dstH)
        val srcPixels = IntArray(srcW * srcH)
        src.getPixels(srcPixels, 0, srcW, 0, 0, srcW, srcH)

        for (y in 0 until dstH) {
            for (x in 0 until dstW) {
                val srcX = x * xRatio
                val srcY = y * yRatio
                pixels[y * dstW + x] = bicubicSample(srcPixels, srcW, srcH, srcX, srcY)
            }
        }
        dst.setPixels(pixels, 0, dstW, 0, 0, dstW, dstH)
        return dst
    }

    private fun bicubicSample(pixels: IntArray, w: Int, h: Int, x: Float, y: Float): Int {
        val x1 = floor(x).toInt()
        val y1 = floor(y).toInt()
        val dx = x - x1
        val dy = y - y1

        var r = 0f
        var g = 0f
        var b = 0f
        var a = 0f

        for (m in -1..2) {
            for (n in -1..2) {
                val px = (x1 + n).coerceIn(0, w - 1)
                val py = (y1 + m).coerceIn(0, h - 1)
                val p = pixels[py * w + px]
                val weight = cubicWeight(dx - n) * cubicWeight(dy - m)
                a += ((p shr 24) and 0xFF) * weight
                r += ((p shr 16) and 0xFF) * weight
                g += ((p shr 8) and 0xFF) * weight
                b += (p and 0xFF) * weight
            }
        }
        return (clamp(a.toInt()) shl 24) or
                (clamp(r.toInt()) shl 16) or
                (clamp(g.toInt()) shl 8) or
                clamp(b.toInt())
    }

    private fun cubicWeight(t: Float): Float {
        val at = abs(t)
        return when {
            at <= 1f -> 1.5f * at * at * at - 2.5f * at * at + 1f
            at < 2f -> -0.5f * at * at * at + 2.5f * at * at - 4f * at + 2f
            else -> 0f
        }
    }

    /**
     * Aproximação de Lanczos-3 (mais cara, melhor para fotos).
     * Limitada a fatores moderados para evitar travamentos em dispositivos mid-range.
     */
    private fun scaleLanczosApprox(src: Bitmap, dstW: Int, dstH: Int): Bitmap {
        // Para MVP e dispositivos como Mali-G68, usamos bicúbico de alta qualidade
        // como aproximação segura. Uma implementação completa de Lanczos exigiria NDK.
        return scaleBicubic(src, dstW, dstH)
    }

    // ========== Ajustes de cor ==========

    private fun applyColorAdjustments(
        src: Bitmap,
        contrast: Float,
        saturation: Float,
        brightness: Float
    ): Bitmap {
        val cm = ColorMatrix()

        // Contraste + Brilho
        val scale = contrast
        val translate = (-0.5f * scale + 0.5f + brightness) * 255f
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                scale, 0f, 0f, 0f, translate,
                0f, scale, 0f, 0f, translate,
                0f, 0f, scale, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(contrastMatrix)

        // Saturação
        val satMatrix = ColorMatrix()
        satMatrix.setSaturation(saturation)
        cm.postConcat(satMatrix)

        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(cm)
        }
        val result = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(result).drawBitmap(src, 0f, 0f, paint)
        return result
    }

    // ========== Nitidez (Unsharp Mask simplificado) ==========

    private fun applySharpen(src: Bitmap, amount: Float): Bitmap {
        // Kernel de nitidez clássico
        val strength = amount.coerceIn(0f, 2f)
        val kernel = floatArrayOf(
            0f, -strength, 0f,
            -strength, 1f + 4f * strength, -strength,
            0f, -strength, 0f
        )
        return convolve3x3(src, kernel)
    }

    // ========== Redução de ruído ==========

    private fun applyNoiseReduction(src: Bitmap, amount: Float): Bitmap {
        // Média ponderada 3x3 controlada pela intensidade
        val a = amount.coerceIn(0f, 1f)
        val center = 1f - a * 0.6f
        val side = a * 0.1f
        val kernel = floatArrayOf(
            side, side, side,
            side, center, side,
            side, side, side
        )
        return convolve3x3(src, kernel)
    }

    private fun convolve3x3(src: Bitmap, kernel: FloatArray): Bitmap {
        val w = src.width
        val h = src.height
        val srcPixels = IntArray(w * h)
        src.getPixels(srcPixels, 0, w, 0, 0, w, h)
        val dstPixels = IntArray(w * h)

        for (y in 0 until h) {
            for (x in 0 until w) {
                var r = 0f
                var g = 0f
                var b = 0f
                var a = 0f
                var k = 0
                for (ky in -1..1) {
                    for (kx in -1..1) {
                        val px = (x + kx).coerceIn(0, w - 1)
                        val py = (y + ky).coerceIn(0, h - 1)
                        val p = srcPixels[py * w + px]
                        val weight = kernel[k++]
                        a += ((p shr 24) and 0xFF) * weight
                        r += ((p shr 16) and 0xFF) * weight
                        g += ((p shr 8) and 0xFF) * weight
                        b += (p and 0xFF) * weight
                    }
                }
                dstPixels[y * w + x] =
                    (clamp(a.toInt()) shl 24) or
                            (clamp(r.toInt()) shl 16) or
                            (clamp(g.toInt()) shl 8) or
                            clamp(b.toInt())
            }
        }
        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        result.setPixels(dstPixels, 0, w, 0, 0, w, h)
        return result
    }

    private fun clamp(v: Int): Int = v.coerceIn(0, 255)
}
