package com.aetherscale.app.ui.theme

import androidx.compose.ui.graphics.Color

// Tema escuro moderno com detalhes azul/ciano
val CyanPrimary = Color(0xFF00E5FF)
val CyanSecondary = Color(0xFF00BCD4)
val CyanDark = Color(0xFF0097A7)
val CyanLight = Color(0xFF84FFFF)

val DarkBackground = Color(0xFF0A0E14)
val DarkSurface = Color(0xFF12181F)
val DarkSurfaceVariant = Color(0xFF1A2330)
val DarkCard = Color(0xFF161D27)

val TextPrimary = Color(0xFFE8EEF5)
val TextSecondary = Color(0xFF9AA8B8)
val TextMuted = Color(0xFF6B7A8A)

val Success = Color(0xFF4CAF50)
val Warning = Color(0xFFFFB300)
val Error = Color(0xFFEF5350)
val Experimental = Color(0xFFFF9800)
val Unsupported = Color(0xFF78909C)
