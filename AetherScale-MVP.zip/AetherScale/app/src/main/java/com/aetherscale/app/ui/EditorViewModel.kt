package com.aetherscale.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aetherscale.app.processing.ImageProcessor
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.InputStream

class EditorViewModel : ViewModel() {

    var originalBitmap by mutableStateOf<Bitmap?>(null)
        private set

    var processedBitmap by mutableStateOf<Bitmap?>(null)
        private set

    var isProcessing by mutableStateOf(false)
        private set

    var lastResult by mutableStateOf<ImageProcessor.ProcessResult?>(null)
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    // Controles
    var scaleFactor by mutableFloatStateOf(2.0f)
    var sharpness by mutableFloatStateOf(0.4f)
    var contrast by mutableFloatStateOf(1.05f)
    var saturation by mutableFloatStateOf(1.05f)
    var brightness by mutableFloatStateOf(0.0f)
    var noiseReduction by mutableFloatStateOf(0.15f)
    var selectedAlgorithm by mutableStateOf(ImageProcessor.ScaleAlgorithm.BICUBIC)
    var selectedPresetIndex by mutableStateOf(0)

    private var processJob: Job? = null

    fun loadImage(inputStream: InputStream) {
        try {
            val options = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inSampleSize = 1
            }
            // Decodifica com proteção de memória
            val bmp = BitmapFactory.decodeStream(inputStream, null, options)
            if (bmp == null) {
                errorMessage = "Não foi possível decodificar a imagem."
                return
            }
            // Limita tamanho inicial para evitar OOM em aparelhos de 6 GB
            val maxDim = 2048
            val finalBmp = if (bmp.width > maxDim || bmp.height > maxDim) {
                val ratio = minOf(maxDim.toFloat() / bmp.width, maxDim.toFloat() / bmp.height)
                val w = (bmp.width * ratio).toInt().coerceAtLeast(1)
                val h = (bmp.height * ratio).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(bmp, w, h, true)
                if (scaled !== bmp) bmp.recycle()
                scaled
            } else {
                bmp
            }
            clearBitmaps()
            originalBitmap = finalBmp
            processedBitmap = null
            lastResult = null
            errorMessage = null
            applyPreset(0) // aplica equilibrado por padrão
        } catch (e: OutOfMemoryError) {
            errorMessage = "Memória insuficiente para carregar a imagem."
        } catch (e: Exception) {
            errorMessage = "Erro ao carregar: ${e.message}"
        }
    }

    fun applyPreset(index: Int) {
        if (index !in ImageProcessor.PRESETS.indices) return
        selectedPresetIndex = index
        val p = ImageProcessor.PRESETS[index].params
        scaleFactor = p.scaleFactor
        selectedAlgorithm = p.algorithm
        sharpness = p.sharpness
        contrast = p.contrast
        saturation = p.saturation
        brightness = p.brightness
        noiseReduction = p.noiseReduction
        process()
    }

    fun process() {
        val src = originalBitmap ?: return
        processJob?.cancel()
        processJob = viewModelScope.launch {
            isProcessing = true
            errorMessage = null
            try {
                val params = ImageProcessor.ProcessParams(
                    scaleFactor = scaleFactor,
                    algorithm = selectedAlgorithm,
                    sharpness = sharpness,
                    contrast = contrast,
                    saturation = saturation,
                    brightness = brightness,
                    noiseReduction = noiseReduction
                )
                val result = ImageProcessor.process(src, params)
                // Libera bitmap anterior
                processedBitmap?.let {
                    if (!it.isRecycled && it !== src) it.recycle()
                }
                processedBitmap = result.bitmap
                lastResult = result
            } catch (e: OutOfMemoryError) {
                errorMessage = "Memória insuficiente. Reduza a escala ou a qualidade."
            } catch (e: Exception) {
                errorMessage = "Falha no processamento: ${e.message}"
            } finally {
                isProcessing = false
            }
        }
    }

    fun reset() {
        processedBitmap?.let {
            if (!it.isRecycled) it.recycle()
        }
        processedBitmap = null
        lastResult = null
        applyPreset(0)
    }

    private fun clearBitmaps() {
        originalBitmap?.let { if (!it.isRecycled) it.recycle() }
        processedBitmap?.let { if (!it.isRecycled) it.recycle() }
        originalBitmap = null
        processedBitmap = null
    }

    override fun onCleared() {
        super.onCleared()
        processJob?.cancel()
        clearBitmaps()
    }
}
