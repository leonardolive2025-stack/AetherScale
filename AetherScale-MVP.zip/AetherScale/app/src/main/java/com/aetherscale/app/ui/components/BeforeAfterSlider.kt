package com.aetherscale.app.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/**
 * Comparador Antes/Depois com slider interativo.
 */
@Composable
fun BeforeAfterSlider(
    before: Bitmap?,
    after: Bitmap?,
    modifier: Modifier = Modifier
) {
    var sliderPosition by remember { mutableFloatStateOf(0.5f) }
    var boxWidth by remember { mutableIntStateOf(1) }
    val density = LocalDensity.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(
                if (before != null && before.height > 0)
                    before.width.toFloat() / before.height
                else 1f
            )
            .clipToBounds()
            .background(Color.Black)
            .onSizeChanged { boxWidth = it.width }
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, _ ->
                    val newPos = (change.position.x / size.width).coerceIn(0.02f, 0.98f)
                    sliderPosition = newPos
                }
            }
    ) {
        // Imagem "Depois" (fundo completo)
        if (after != null && !after.isRecycled) {
            Image(
                bitmap = after.asImageBitmap(),
                contentDescription = "Depois",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Imagem "Antes" (recortada pela posição do slider)
        if (before != null && !before.isRecycled) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(sliderPosition)
                    .clipToBounds()
            ) {
                Image(
                    bitmap = before.asImageBitmap(),
                    contentDescription = "Antes",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxHeight()
                        .wrapContentWidth(unbounded = true)
                        .align(Alignment.CenterStart)
                )
            }
        }

        // Linha divisória
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(2.dp)
                .offset { IntOffset((sliderPosition * boxWidth).roundToInt() - 1, 0) }
                .background(MaterialTheme.colorScheme.primary)
        )

        // Handle
        Box(
            modifier = Modifier
                .offset {
                    IntOffset(
                        (sliderPosition * boxWidth).roundToInt() - with(density) { 18.dp.roundToPx() },
                        0
                    )
                }
                .align(Alignment.CenterStart)
                .size(36.dp)
                .background(MaterialTheme.colorScheme.primary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.DragHandle,
                contentDescription = "Arrastar",
                tint = Color.Black,
                modifier = Modifier.size(20.dp)
            )
        }

        // Labels
        Text(
            text = "Antes",
            style = MaterialTheme.typography.labelMedium,
            color = Color.White.copy(alpha = 0.85f),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
                .background(Color.Black.copy(alpha = 0.55f), shape = MaterialTheme.shapes.small)
                .padding(horizontal = 6.dp, vertical = 2.dp)
        )
        Text(
            text = "Depois",
            style = MaterialTheme.typography.labelMedium,
            color = Color.White.copy(alpha = 0.85f),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .background(Color.Black.copy(alpha = 0.55f), shape = MaterialTheme.shapes.small)
                .padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
