package com.aetherscale.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aetherscale.app.ui.theme.*
import com.aetherscale.app.util.DeviceDiagnostics
import com.aetherscale.app.util.DeviceInfo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosticsScreen(
    diagnostics: DeviceDiagnostics?,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Diagnóstico") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary,
                    navigationIconContentColor = TextPrimary
                )
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            if (diagnostics == null) {
                Text("Coletando dados do dispositivo…", color = TextSecondary)
                return@Column
            }

            InfoCard("Modelo", "${diagnostics.manufacturer} ${diagnostics.model}")
            InfoCard("Android", "${diagnostics.androidVersion} (API ${diagnostics.apiLevel})")
            InfoCard("Memória total", DeviceInfo.formatRam(diagnostics.totalRamMb))
            InfoCard("Memória disponível", DeviceInfo.formatRam(diagnostics.availableRamMb))
            InfoCard("Resolução", "${diagnostics.screenWidthPx} × ${diagnostics.screenHeightPx}")
            InfoCard("Densidade", "${diagnostics.densityDpi} dpi")
            InfoCard("Taxa de atualização", "${diagnostics.refreshRateHz} Hz")

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Recomendações para este aparelho",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "• Comece com escala 1.5×–2× e resolução de saída ≤ 1080p.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Text(
                        "• Use o preset “Equilibrado” ou “Vídeo” para menor consumo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Text(
                        "• Evite Lanczos em imagens muito grandes se notar aquecimento.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Text(
                        "• A RAM virtual não equivale a memória física rápida — monitore o uso.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Text(
                        "• O app reduz carga automaticamente quando possível para evitar superaquecimento.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoCard(label: String, value: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            Text(value, color = CyanLight, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
