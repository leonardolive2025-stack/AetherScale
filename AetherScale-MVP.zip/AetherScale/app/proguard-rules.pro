# AetherScale - regras ProGuard (MVP sem ofuscação agressiva)
-keep class com.aetherscale.app.** { *; }
